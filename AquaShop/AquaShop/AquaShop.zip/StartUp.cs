﻿namespace AquaShop
{
    using System;

    using AquaShop.Core;
    using AquaShop.Core.Contracts;
    using AquaShop.Models.Fish;

    public class StartUp
    {
        public static void Main()
        {
            FreshwaterFish fish = new FreshwaterFish("gosho", "zlatna ribka", 50);

            fish.Eat();
            Console.WriteLine(fish.Size);

            SaltwaterFish mitko = new SaltwaterFish("mitko", "piranq", 200);
            mitko.Eat();
            Console.WriteLine(mitko.Size);

            return;
            //Don't forget to comment out the commented code lines in the Engine class!
            IEngine engine = new Engine();
            engine.Run();
        }
    }
}
