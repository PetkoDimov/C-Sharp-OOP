﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Puppy gosho = new Puppy();
            gosho.Eat();
            gosho.Bark();
            gosho.Weep();

        }
    }
}
