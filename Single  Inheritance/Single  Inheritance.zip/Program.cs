﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            Dog sparky = new Dog();
            sparky.Bark();
            sparky.Eat();

        }
    }
}
